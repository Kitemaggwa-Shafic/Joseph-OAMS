-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 19, 2017 at 03:34 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `admission`
--
CREATE DATABASE `admission` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `admission`;

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE IF NOT EXISTS `administrator` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`admin_id`, `username`, `password`, `usertype`) VALUES
(2, 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `course_student`
--

CREATE TABLE IF NOT EXISTS `course_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `AutoNumber` varchar(100) NOT NULL,
  `coursename` varchar(50) NOT NULL,
  `period` varchar(50) NOT NULL,
  `sponsorname` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `course_student`
--

INSERT INTO `course_student` (`id`, `AutoNumber`, `coursename`, `period`, `sponsorname`) VALUES
(1, 'QWA12Q', 'Barchelor Of Science in Information Technology', '17-03-2017', 'Fumu'),
(4, 'Ssekamatte', 'BEDS', '2 years', 'Government'),
(8, 'Ssekamatte', 'BEDS', '3 years', 'Government'),
(9, 'Ssekamatte', 'BEDS', '3 years', 'Government'),
(10, 'Ssekamatte', 'BEDS', '3 years', 'Government'),
(11, 'Ssekamatte', 'Bachelor of Science in Information Technology', '3 years', 'Government');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `coursename` varchar(100) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `period` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`Id`, `coursename`, `faculty`, `period`) VALUES
(1, 'BIT', 'Science & Technology', '3 Years'),
(2, 'BBBA', 'Science and Technology', '2 years');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `facultyname` varchar(50) NOT NULL,
  `contacts` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `facultyname`, `contacts`, `email`) VALUES
(1, 'Science and Technology', '0757233453', 'dean@ict.co.umu');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `autonumber` varchar(50) NOT NULL,
  `emailaddress` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `cpassword` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `autonumber`, `emailaddress`, `fullname`, `password`, `cpassword`) VALUES
(4, '', 'admin@yahoo.com', 'kjsn', 'kjsn', 'kjsn');

-- --------------------------------------------------------

--
-- Table structure for table `sponsorship`
--

CREATE TABLE IF NOT EXISTS `sponsorship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sponsorname` varchar(50) NOT NULL,
  `renewal` varchar(50) NOT NULL,
  `sponsortype` varchar(50) NOT NULL,
  `period` varchar(50) NOT NULL,
  `Contacts` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sponsorship`
--

INSERT INTO `sponsorship` (`id`, `sponsorname`, `renewal`, `sponsortype`, `period`, `Contacts`, `Email`) VALUES
(2, 'Government', 'Annual', 'Full', '1 Year', '12222', 'gov@ymail.com');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AutoNumber` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `DOB` varchar(100) NOT NULL,
  `contacts` varchar(100) NOT NULL,
  `maritalstatus` varchar(100) NOT NULL,
  `age` varchar(11) NOT NULL,
  `nation` varchar(80) NOT NULL,
  `image` varchar(700) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Id`, `AutoNumber`, `firstname`, `lastname`, `gender`, `DOB`, `contacts`, `maritalstatus`, `age`, `nation`, `image`) VALUES
(1, 'QWA12Q', 'Ssekamatte', 'Tom Frankie', 'male', '20-04-2017', '757233453', 'married', '120', 'Rwanda', 'uploads/die.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `uace`
--

CREATE TABLE IF NOT EXISTS `uace` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexno` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `school` varchar(50) NOT NULL,
  `subject1` varchar(50) NOT NULL,
  `grade1` varchar(50) NOT NULL,
  `subject2` varchar(50) NOT NULL,
  `grade2` varchar(50) NOT NULL,
  `subject3` varchar(50) NOT NULL,
  `grade3` varchar(50) NOT NULL,
  `SUB_MATC_COMP` varchar(50) NOT NULL,
  `GP` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `uace`
--

INSERT INTO `uace` (`id`, `indexno`, `year`, `school`, `subject1`, `grade1`, `subject2`, `grade2`, `subject3`, `grade3`, `SUB_MATC_COMP`, `GP`) VALUES
(1, 'U5102/505', '15-03-2017', 'Kampala', 'Physics', 'B', 'Economics', 'A', 'Maths', 'C', 'C', 0),
(4, 'qws', '2023', 'rakai', 'Maths', 'A', 'Physics', 'B', 'Economics', 'A', 'O', 0);

-- --------------------------------------------------------

--
-- Table structure for table `uce`
--

CREATE TABLE IF NOT EXISTS `uce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexno` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `school` varchar(50) NOT NULL,
  `MATHS` varchar(50) NOT NULL,
  `ENGLISH` varchar(50) NOT NULL,
  `PHYSICS` varchar(50) NOT NULL,
  `CHEMISTRY` varchar(50) NOT NULL,
  `BIOLOGY` varchar(50) NOT NULL,
  `GEOGRAPHY` varchar(50) NOT NULL,
  `HISTORY` varchar(50) NOT NULL,
  `COMMERCE` varchar(50) NOT NULL,
  `COMPUTER` varchar(50) NOT NULL,
  `FINEART` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `uce`
--

INSERT INTO `uce` (`id`, `indexno`, `year`, `school`, `MATHS`, `ENGLISH`, `PHYSICS`, `CHEMISTRY`, `BIOLOGY`, `GEOGRAPHY`, `HISTORY`, `COMMERCE`, `COMPUTER`, `FINEART`) VALUES
(7, 'U211/12', '2022', 'mugongo', 'D2', 'D1', 'D1', 'D1', 'D1', 'D1', 'D1', 'D1', 'D1', 'D1'),
(9, 'aa', '2022', 'saw', 'D1', 'D1', 'D2', 'D2', 'D1', 'C5', 'D1', 'D2', 'C3', 'C6');
