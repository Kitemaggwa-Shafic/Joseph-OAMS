-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2017 at 06:34 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `admission`
--
CREATE DATABASE `admission` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `admission`;

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE IF NOT EXISTS `administrator` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`admin_id`, `username`, `password`, `usertype`) VALUES
(2, 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `course_student`
--

CREATE TABLE IF NOT EXISTS `course_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `AutoNumber` varchar(100) NOT NULL,
  `coursename` varchar(50) NOT NULL,
  `period` varchar(50) NOT NULL,
  `sponsorname` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `course_student`
--

INSERT INTO `course_student` (`id`, `AutoNumber`, `coursename`, `period`, `sponsorname`) VALUES
(1, 'QWA12Q', 'Barchelor Of Science in Information Technology', '17-03-2017', 'Fumu');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `coursename` varchar(100) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `period` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`Id`, `coursename`, `faculty`, `period`) VALUES
(1, 'BIT', 'Science & Technology', '3 Years');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `facultyname` varchar(50) NOT NULL,
  `contacts` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `facultyname`, `contacts`, `email`) VALUES
(1, 'Science and Technology', '0757233453', 'dean@ict.co.umu');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emailaddress` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `cpassword` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `emailaddress`, `fullname`, `password`, `cpassword`) VALUES
(3, 'kitemaggwashafic@gmail.com', 'kjsn', 'kjsn', 'kjsn'),
(4, 'fumu@yahoo.com', 'kjsn', 'kjsn', 'kjsn'),
(5, 'kk@ymail.com', 'k', 'k', 'k'),
(6, 'kk@ymail.com', 'k', 'a', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `sponsorship`
--

CREATE TABLE IF NOT EXISTS `sponsorship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sponsorname` varchar(50) NOT NULL,
  `renewal` varchar(50) NOT NULL,
  `sponsortype` varchar(50) NOT NULL,
  `period` varchar(50) NOT NULL,
  `Contacts` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sponsorship`
--

INSERT INTO `sponsorship` (`id`, `sponsorname`, `renewal`, `sponsortype`, `period`, `Contacts`, `Email`) VALUES
(2, 'Governmeny', 'Annual', 'Full', '1 Year', '12222', 'gov@ymail.com');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AutoNumber` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `DOB` varchar(100) NOT NULL,
  `contacts` varchar(100) NOT NULL,
  `maritalstatus` varchar(100) NOT NULL,
  `age` varchar(11) NOT NULL,
  `points` varchar(50) NOT NULL,
  `nation` varchar(80) NOT NULL,
  `image` varchar(700) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Id`, `AutoNumber`, `firstname`, `lastname`, `gender`, `DOB`, `contacts`, `maritalstatus`, `age`, `points`, `nation`, `image`) VALUES
(1, 'QWA12Q', 'Ssekamatte', 'Tom Frankie', 'male', '20-04-2017', '+256 754836637', 'married', '120', '1313', 'Rwanda', 'uploads/die.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `uace`
--

CREATE TABLE IF NOT EXISTS `uace` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexno` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `school` varchar(50) NOT NULL,
  `subject1` varchar(50) NOT NULL,
  `grade1` varchar(50) NOT NULL,
  `subject2` varchar(50) NOT NULL,
  `grade2` varchar(50) NOT NULL,
  `subject3` varchar(50) NOT NULL,
  `grade3` varchar(50) NOT NULL,
  `subject4` varchar(50) NOT NULL,
  `grade4` varchar(50) NOT NULL,
  `subject5` varchar(50) NOT NULL,
  `grade5` int(50) NOT NULL,
  `subject6` varchar(50) NOT NULL,
  `grade6` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `uace`
--

INSERT INTO `uace` (`id`, `indexno`, `year`, `school`, `subject1`, `grade1`, `subject2`, `grade2`, `subject3`, `grade3`, `subject4`, `grade4`, `subject5`, `grade5`, `subject6`, `grade6`) VALUES
(1, 'U5102/505', '15-03-2017', 'Kampala', 'Physics', 'B', 'Economics', 'A', 'Maths', 'C', 'Art', 'C', 'Computer', 0, 'Entrepreneurship', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `uce`
--

CREATE TABLE IF NOT EXISTS `uce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexno` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `school` varchar(50) NOT NULL,
  `subject1` varchar(50) NOT NULL,
  `grade1` varchar(50) NOT NULL,
  `subject2` varchar(50) NOT NULL,
  `grade2` varchar(50) NOT NULL,
  `subject3` varchar(50) NOT NULL,
  `grade3` varchar(50) NOT NULL,
  `subject4` varchar(50) NOT NULL,
  `grade4` varchar(50) NOT NULL,
  `subject5` varchar(50) NOT NULL,
  `grade5` varchar(50) NOT NULL,
  `subject6` varchar(50) NOT NULL,
  `grade6` varchar(50) NOT NULL,
  `subject7` varchar(50) NOT NULL,
  `grade7` varchar(50) NOT NULL,
  `subject8` varchar(50) NOT NULL,
  `grade8` varchar(50) NOT NULL,
  `subject9` varchar(50) NOT NULL,
  `grade9` varchar(50) NOT NULL,
  `subject10` varchar(50) NOT NULL,
  `grade10` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `uce`
--

INSERT INTO `uce` (`id`, `indexno`, `year`, `school`, `subject1`, `grade1`, `subject2`, `grade2`, `subject3`, `grade3`, `subject4`, `grade4`, `subject5`, `grade5`, `subject6`, `grade6`, `subject7`, `grade7`, `subject8`, `grade8`, `subject9`, `grade9`, `subject10`, `grade10`) VALUES
(5, 'U2130/001', '18-03-2050', 'School', 'English', 'D1', 'Maths', 'C3', 'Chemistry', 'C3', 'Biology', 'C5', 'Biology', 'D2', 'History', 'C5', 'Geography', 'C3', 'Art', 'C4', 'Computer', 'C3', 'Commerce', 'C3'),
(6, 'U2130/001', '16-03-2017', 'Kampala', 'Maths', 'D2', 'Physics', 'C4', 'English', 'C4', 'Chemistry', 'C4', 'Biology', 'C5', 'Geography', 'P7', 'History', 'C4', 'Art', 'C6', 'Computer', 'P7', 'Commerce', 'C5');
